import datetime
from django.db import models
from django.utils import timezone
from django.contrib import admin

#Django models -> https://docs.djangoproject.com/en/3.2/topics/db/models/

# Create your models here.

# In our poll app, we'll create two models: Question (which has a question and a publication date) and Choice (two fields: the text of choice and a vote tally). Each Choice is associated with a Question.

# Time zones -> https://docs.djangoproject.com/en/3.2/topics/i18n/timezones/

class Question(models.Model):
    
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')
    
    #q = Question.objects.get(pk=1)
    #choice_set = q.choice_set.all()
    
    def __str__(self):
        return self.question_text
    
    @admin.display(
        boolean=True,
        ordering='pub_date',
        description='Published recently?',
    )
    
    def was_published_recently(self):
        now = timezone.now()
        return now - datetime.timedelta(days=1) <= self.pub_date <= now
    
class Choice(models.Model):
    
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)
    
    def __str__(self):
        return self.choice_text